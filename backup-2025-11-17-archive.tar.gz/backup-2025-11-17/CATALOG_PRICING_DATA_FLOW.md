# Catalog & Pricing Service - Data Flow

> **Created:** November 8, 2024  
> **Purpose:** Detailed data flow diagrams for Catalog-Pricing integration

---

## 🔄 Flow 1: Product Creation with Base Price

```
Admin Dashboard
      ↓
   [Create Product]
      ↓
┌─────────────────────────────────────────┐
│ 1. Create Product in Catalog Service   │
│    POST /api/v1/catalog/products        │
│    {                                    │
│      name: "Gaming Laptop",             │
│      sku: "LAPTOP-001",                 │
│      description: "...",                │
│      // NO PRICE HERE                   │
│    }                                    │
└─────────────────────────────────────────┘
      ↓
   [Product Created]
   product_id: "prod_123"
      ↓
┌─────────────────────────────────────────┐
│ 2. Set Base Price in Pricing Service   │
│    POST /api/v1/pricing/prices          │
│    {                                    │
│      productId: "prod_123",             │
│      currency: "VND",                   │
│      basePrice: 25000000,               │
│      salePrice: null,                   │
│      effectiveFrom: "2024-11-08"        │
│    }                                    │
└─────────────────────────────────────────┘
      ↓
   [Price Set]
      ↓
   Product Ready!
```

---

## 🔄 Flow 2: Get Single Product with Price

```
User Request: GET /api/v1/catalog/products/prod_123
      ↓
┌─────────────────────────────────────────┐
│ API Gateway                             │
│ Route: /api/v1/catalog/* → Catalog     │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ Catalog Service                         │
│ GET /products/prod_123                  │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 1. Get Product from Database            │
│    SELECT * FROM products               │
│    WHERE id = 'prod_123'                │
│                                         │
│    Result: {                            │
│      id: "prod_123",                    │
│      name: "Gaming Laptop",             │
│      sku: "LAPTOP-001"                  │
│    }                                    │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 2. Check Redis Cache                    │
│    Key: pricing:product:prod_123:VND   │
└─────────────────────────────────────────┘
      ↓
   Cache Miss?
      ↓ Yes
┌─────────────────────────────────────────┐
│ 3. Call Pricing Service (gRPC)          │
│    pricingClient.GetPrice(              │
│      productId: "prod_123",             │
│      currency: "VND"                    │
│    )                                    │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ Pricing Service                         │
│ 1. Get base price from DB               │
│ 2. Apply price rules                    │
│ 3. Apply discounts                      │
│ 4. Return final price                   │
│                                         │
│ Response: {                             │
│   basePrice: 25000000,                  │
│   salePrice: 22500000,                  │
│   finalPrice: 22500000,                 │
│   discountPercent: 10                   │
│ }                                       │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 4. Cache Price (5 minutes)              │
│    SET pricing:product:prod_123:VND     │
│    TTL: 300 seconds                     │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 5. Merge Product + Price                │
│    {                                    │
│      id: "prod_123",                    │
│      name: "Gaming Laptop",             │
│      sku: "LAPTOP-001",                 │
│      price: {                           │
│        basePrice: 25000000,             │
│        salePrice: 22500000,             │
│        finalPrice: 22500000,            │
│        hasDiscount: true                │
│      }                                  │
│    }                                    │
└─────────────────────────────────────────┘
      ↓
   Return to User
```

---

## 🔄 Flow 3: List Products with Bulk Pricing

```
User Request: GET /api/v1/catalog/products?page=1&limit=20
      ↓
┌─────────────────────────────────────────┐
│ Catalog Service                         │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 1. Get Products from Database           │
│    SELECT * FROM products               │
│    LIMIT 20 OFFSET 0                    │
│                                         │
│    Result: 20 products                  │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 2. Extract Product IDs                  │
│    productIds = [                       │
│      "prod_123",                        │
│      "prod_124",                        │
│      ...                                │
│    ]                                    │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 3. Call Pricing Service (Bulk)          │
│    pricingClient.BulkCalculatePrice(    │
│      items: [                           │
│        {productId: "prod_123", qty: 1}, │
│        {productId: "prod_124", qty: 1}, │
│        ...                              │
│      ]                                  │
│    )                                    │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ Pricing Service                         │
│ Process 20 items in parallel            │
│ Return: [                               │
│   {productId: "prod_123", price: ...},  │
│   {productId: "prod_124", price: ...},  │
│   ...                                   │
│ ]                                       │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 4. Merge Products + Prices              │
│    for each product:                    │
│      product.price = priceMap[product.id]│
└─────────────────────────────────────────┘
      ↓
   Return 20 products with prices
```

**Performance:**
- Single product: ~50ms
- 20 products: ~200ms (bulk call)
- With cache: ~10ms

---

## 🔄 Flow 4: Price Update & Cache Invalidation

```
Admin Updates Price
      ↓
┌─────────────────────────────────────────┐
│ Pricing Service                         │
│ PUT /api/v1/pricing/prices/prod_123     │
│ {                                       │
│   basePrice: 23000000,  // Changed!     │
│   salePrice: 20700000                   │
│ }                                       │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 1. Update Price in Database             │
│    UPDATE prices                        │
│    SET base_price = 23000000            │
│    WHERE product_id = 'prod_123'        │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 2. Publish Event (Dapr)                 │
│    Topic: pricing.price.updated         │
│    {                                    │
│      productId: "prod_123",             │
│      oldPrice: 25000000,                │
│      newPrice: 23000000,                │
│      currency: "VND"                    │
│    }                                    │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 3. Catalog Service Subscribes           │
│    Event Handler receives event         │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 4. Invalidate Cache                     │
│    DELETE pricing:product:prod_123:VND  │
└─────────────────────────────────────────┘
      ↓
   Next request will fetch fresh price
```

---

## 🔄 Flow 5: Checkout with Final Price Calculation

```
User Checkout
      ↓
┌─────────────────────────────────────────┐
│ Order Service                           │
│ POST /api/v1/orders                     │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 1. Get Cart Items                       │
│    Items: [                             │
│      {productId: "prod_123", qty: 2},   │
│      {productId: "prod_124", qty: 1}    │
│    ]                                    │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 2. Calculate Final Prices               │
│    pricingService.CalculatePrice(       │
│      items: [...],                      │
│      customerId: "cust_456",            │
│      couponCode: "SAVE20"               │
│    )                                    │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ Pricing Service                         │
│ For each item:                          │
│ 1. Get base price                       │
│ 2. Apply quantity discount              │
│ 3. Apply customer tier discount         │
│ 4. Apply coupon discount                │
│ 5. Calculate tax                        │
│                                         │
│ Return: {                               │
│   subtotal: 50000000,                   │
│   discounts: 5000000,                   │
│   tax: 3600000,                         │
│   total: 48600000                       │
│ }                                       │
└─────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────┐
│ 3. Create Order with Final Prices       │
│    Order saved with calculated amounts  │
└─────────────────────────────────────────┘
```

---

## 🎯 Key Takeaways

### 1. **Data Ownership**
- Catalog owns: Product info (name, SKU, images, categories)
- Pricing owns: All prices (base, sale, cost, rules, discounts)

### 2. **Communication**
- Catalog → Pricing: gRPC calls (GetPrice, BulkCalculatePrice)
- Pricing → Catalog: Events (price.updated)

### 3. **Caching**
- Cache prices for 5 minutes
- Invalidate on price updates
- Graceful degradation if cache/pricing fails

### 4. **Performance**
- Use bulk calls for product lists
- Cache aggressively
- Parallel processing

### 5. **Reliability**
- Always show product even if pricing fails
- Use circuit breaker for pricing calls
- Log errors but don't fail requests

---

## 📊 Performance Metrics

| Operation | Without Cache | With Cache | Target |
|-----------|---------------|------------|--------|
| Single Product | 50ms | 10ms | < 100ms |
| 20 Products | 200ms | 50ms | < 500ms |
| 100 Products | 800ms | 200ms | < 2s |

**Cache Hit Ratio Target:** > 90%

---

**See also:** `CATALOG_PRICING_INTEGRATION.md` for implementation details
